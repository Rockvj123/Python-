print("Armstrong Number")
num=int(input("Enter a number:"))
sum1=0
n=num
p=len(str(num))
for i in range(0,p):
  rem=num%10
  sum1=sum1+rem**p
  num=num//10
if sum1 == n:
  print("The given number is Armstrong",sum1)
else:
  print("The given number is not Armstrong",sum1)
