from numpy import *
a=[]
b=[]
print("---ARRAY COMPARISON---")
n=int(input("Enter the array size:"))
print("Enter the element for a one by one...")
for i in range(n):
    temp=int(input())
    a.append(temp)
a=array(a)

print("Enter the element for b one by one...")
for i in range(n):
    temp=int(input())
    b.append(temp)
b=array(b)

print("Array a=",a)
print("Array b=",b)

print("Result of a==b:",a==b)
print("Result of a<=b:",a<=b)
print("Result of a>b:",a>b)

print()
print("logical_and() for a>0 and a<10:",logical_and(a>0,a<10))
print("logical_or() for b>0 or b==4:",logical_or(b>0,b==4))

print()
c=a==b
print("a==b",c)
print("Apply any() and all() on c...")
print("any() function:",any(c))
print("all() function:",all(c))

print()
print("where() function on a:",where(a%2==0,a,0))

print()
print("nonzero() function on b:",nonzero(b))
