def fact(n):
  if(n==0 or n==1):
    return n
  else:
    return n*fact(n-1)
print("Permutaion & Combination")
n=int(input("Enter n vaue:"))
r=int(input("Enter r vaue:"))
if(n>r):
  print("Combination")  
  result=fact(n)/(fact(n-r)*fact(r))
  print("Result=",result)
  print("Permutation")  
  result=fact(n)/fact(n-r)
  print("Result=",result)
else:
  print("Incorrect- r is greater than n")
