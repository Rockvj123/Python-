print("Palindrome Number")
num=int(input("Enter a Number:"))
temp=num
s=0
while num>0:
  rem=num%10
  s=s*10+rem
  num=num//10
if temp == s:
  print("The given number is palindrome")
else:
  print("The given number is not palindrome")
