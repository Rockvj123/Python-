def create_dict():
    dt=dict()
    n=int(input("Enter number of value:"))
    print("Enter both key and value one by one...")
    for i in range(n):
        key=input("Enter key:")
        val=input("Enter value:")
        dt[key]=val
    return dt

    
print("-----DICTIONARY-----")
print("---Create a Dictionary---")
dt = create_dict()

print()
print("Keys are...",dt.keys())
print("Values are...",dt.values())

print()
print("Accessing an element from dict")
key=input("Enter a key:")
print("The value is...",dt[key])

print()
print("Add element to dict")
key=input("Enter a key:")
val=input("Enter a value:")
dt[key]=val
print(dt)

print()
print("Updating Existing data")
key=input("Enter a key:")
val=input("Enter a new value:")
dt.update({key:val})
print(dt)

print()
print("Remove an element from dict")
print("---Using key...")
key=input("Enter a key to remove:")
dt.pop(key)
print(dt)

print()
print("---remove last element...")
dt.popitem()
print(dt)

print()
print("Copy dict")
dt1=dt.copy()
print(dt1)
