print("*** Searching Element in an Array ***")
import array as ar
g=int(input("Enter the No.of elements:"))
lg=list()
for i in range(0,g):
    x=int(input())
    lg.append(x)
rg=ar.array("i",lg)
print(rg)
fx=int(input("Enter the find element:"))
temp=0
for i in range(0,g):
    if(rg[i]==fx):
        print("Found Element Position is->",i)        
        temp=1
if temp == 0:
        print("Not present element->",g)

