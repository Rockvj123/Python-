import array as ar
print("Sorting an Array")
n=int(input("Enter the Size of Elements:"))
ls=list()
for i in range(0,n):
    nw=int(input())
    ls.append(nw)
a=ar.array("i",ls)
for i in range(0,n):
    for j in range(i,n):
        if a[i]>a[j]:
            a[i]=a[i]+a[j]
            a[j]=a[i]-a[j]
            a[i]=a[i]-a[j]
print("Ascending Order")
for i in a:
    print(i)
des=a[::-1]
print("Decending Order")
for i in des:
    print(i)
