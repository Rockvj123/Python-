from numpy import *
def createMatrix(rows,cols):
    a=[]
    for i in range(rows):
        row=[]
        for j in range(cols):
            x=int(input())
            row.append(x)
        a.append(row)
    return a

print("---MATRIX MULTIPLICATION---")
m=int(input("Enter the row size:"))
n=int(input("Enter the column size:"))
print("Matrix A")
matrix1=createMatrix(m,n)

print("Matrix B")
matrix2=createMatrix(m,n)

a = matrix(matrix1)
b = matrix(matrix2)

print(a)
print(b)

print("Multiplication Result:")
print(a*b)
