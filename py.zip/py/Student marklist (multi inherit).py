class Base:
    def getData(self,name,rollno):
        self.name=name
        self.rollno=rollno
class Base2:
    def getMarks(self,n):
        self.n=n
        self.ls=list()
        print("Enter the marks one by one...")
        for i in range(n):
            mark=int(input())
            self.ls.append(mark)
    def calculate(self):
        self.total=0
        for i in self.ls:
            self.total=self.total+i
        self.avg=self.total/self.n
class Derived(Base,Base2):
    def display(self):
        print("Name : ",self.name)
        print("Roll Number : ",self.rollno)
        print("Marks in various subjects...")
        for i in self.ls:
            print(i)
        print("Total : ",self.total)
        print("Average : ",self.avg)
        if(self.avg>=85 and self.avg<=100):
            self.grade='A'
        elif(self.avg>=70 and self.avg<85):
            self.grade='B'
        elif(self.avg>60 and self.avg<70):
            self.grade='C'
        else:
            self.grade='Fail'
        print("Grade : ",self.grade)

d=Derived()
print("~~~MULTIPLE INHERITANCE~~~")
name=input("Enter name:")
rollno=input("Enter roll number:")
d.getData(name,rollno)
subject=int(input("Enter number of subjects to add marks..."))
d.getMarks(subject)
d.calculate()
d.display()
