from numpy import *
def creatematrix(rows,cols):
    a=[]
    for i in range(rows):
        row=[]
        for j in range(cols):
            x=int(input())
            row.append(x)
        a.append(row)
    return a
m=int(input("Enter the row size:"))
n=int(input("enter the coloum size:"))
print("enter the element for the matrix:")
matrix1=creatematrix(m,n)
print(matrix(matrix1))
print("The result is..\n",matrix(transpose(matrix1)))
