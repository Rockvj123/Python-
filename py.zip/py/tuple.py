print("TUPLE")
print("~~~~~~")
def cr_tuple():
    tp=list()
    n=int(input("ENter the element to insert:"))
    print("ENter the elements one by one:")
    for i in range(n):
        data=int(input())
        tp.append(data)
    tp=tuple(tp)
    return tp
print("Create a Tuple")
print(cr_tuple())
print("Concatnate two tuple")
print("=================")
print("Tuple1:")
tx=cr_tuple()
print("Tuple2:")
tx1=cr_tuple()
tx2=tx+tx1
print("After Concat:",tx2)
print()
print("Find the no.of times values is repeated using count()")
val=int(input("ENter the value:"))
print("{0}is repeated {1}".format(val,tx2.count(val)))
print()
print("Finding index")
print("-----------")
val1=int(input("ENter the value to find value:"))
print("INdex of {0} is {1}".format(val1,tx2.index(val1)))
print("Slicing Tuple")
st=int(input("Enter start position:"))
sr=int(input("enter end position:"))
print(tx2[st:sr])
print("Sum of Tuple")
print("Sum result:",sum(tx2))

      
       
