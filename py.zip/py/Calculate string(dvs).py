print("***Calculate String***")
s=input("Type any Sentence...\n")
word=s.split()
print("Number of words in string:",len(word))
digit=0
vowel=0
space=0
uppercase=0                           
lowercase=0
for i in range(0,len(s)):
  if(s[i]>='0' and s[i]<='9'):
    digit+=1
  elif(s[i]==' '):
    space+=1
  if(s[i]=='a' or s[i]=='e' or s[i]=='i' or s[i]=='o' or s[i]=='u' or s[i]=='A' or s[i]=='E' or s[i]=='I' or s[i]=='O' or s[i]=='U'):
    vowel+=1
  if(s[i].isupper()):
    uppercase+=1
  if(s[i].islower()):
    lowercase+=1
print("Number of Digits:",digit)
print("Number of Vowels:",vowel)
print("Number of Blanks:",digit)
print("Number of uppercase:",uppercase)
print("Number of lowercase:",lowercase)

