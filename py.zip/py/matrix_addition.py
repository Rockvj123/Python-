from numpy import *
def createMatrix(rows,cols):
    a=[]
    for i in range(rows):
        row=[]
        for j in range(cols):
            x=int(input())
            row.append(x)
        a.append(row)
    return a


print("---MATRIX ADDITION & SUBTRACTION---")
m=int(input("Enter the row size:"))
n=int(input("Enter the column size:"))
print("Matrix A")
matrix1=createMatrix(m,n)
a=matrix(matrix1)
print("Matrix B")
matrix2=createMatrix(m,n)
b=matrix(matrix2)
print("A matrix :\n",a)
print("B matrix:\n",b)


print("Addition Result:\n",a+b)


print("Subtraction Result:\n",a-b)
