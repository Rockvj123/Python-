class Base:
    def getdata(self,a,b):
        self.a=a
        self.b=b
class derived(Base):
    def arith(self):
        print("Addition Result:",self.a+self.b)
        print("Subtraction Result:",self.a-self.b)
        print("Multiplication Result:",self.a*self.b)
        print("Division Result:",self.a/self.b)
        print("Modular Result:",self.a/self.b)
print("\t Arithmetic Operation Using Single Inheritance")
m=derived()
a=int(input("1st value:"))
b=int(input("2nd value:"))
m.getdata(a,b)
m.arith()
