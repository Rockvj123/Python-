print("~~~STRING MANIPULATION~~~")
str1=input("Enter string 1:")
str2=input("Enter string 2:")
print("Length of Str1: ",len(str1))
print("Concatenate two String: ",str1+str2);

print()
print("---Slicing a SubString---")
st=input("Enter a string:")
start=int(input("Enter starting index:"))
end=int(input("Enter Ending index:"))
print("The Result is...",st[start:end])

print()
print("---Repeating a String---")
st=input("Enter a string:")
re=int(input("Enter number of times repeat:"))
print("The Result is...",st*re)

print()
print("---Checking Membership---")
st=input("Enter a string:")
sub=input("Enter a substring:")
if sub in st:
    print("The substring is present in the main string")
else:
    print("The substring is not present in the main string")

print()
print("---Removing Space from a String---")
st=input("Enter a string:")
print("Remove space on both sides using strip()...",st.strip())
print("Remove space on left side using lstrip()...",st.lstrip())
print("Remove space on right side using rstrip()...",st.rstrip())

print()
print("---Finding Substring---")
st=input("Enter a string:")
sub=input("Enter a substring:")
fn=st.find(sub)
if(fn==-1):
    print("Substring is not found in main string")
else:
    print("Substring is found at ",fn+1,"position")

print()
print("---Count substring---")
st=input("Enter a string:")
sub=input("Enter a substring:")
print("Substring is ",st.count(sub),"times present in main string")

print()
print("---Splitting and Joining a string---")
st=input("Enter a string:")
separator=input("Enter a seperator string:")
ls=st.split(separator)
print("The Result is...",ls)
separator=input("Enter a separator to join:")
print("Joining a string...",separator.join(ls))

print()
print("---Formating String---")
name=input("Enter your name:")
rollno=input("Enter your roll number:")
print("{0} roll number is {1}".format(name,rollno))

print()
print("---Sorting a String---")
n=int(input("Enter number of elements:"))
ls=[]
print("Enter the elements one by one:")
for i in range(n):
    st=input()
    ls.append(st)
print("After Sorting:",sorted(ls))
